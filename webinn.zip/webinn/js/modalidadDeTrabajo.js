const toggleDown = document.getElementById("toggle-down");
const toggleUp = document.getElementById("toggle-up");
const pasosTitle = document.getElementById("pasosTitle");
const pasosP = document.getElementById("pasosP");

toggleDown.addEventListener("click", () => {
    pasosP.classList.toggle("pasosP--show");
    pasosTitle.classList.toggle("pasosTitle--hidden")
});

toggleUp.addEventListener("click", () => {
    pasosP.classList.toggle("pasosP--show");
    pasosTitle.classList.toggle("pasosTitle--hidden")
});

const toggleDown2 = document.getElementById("toggle-down2");
const toggleUp2 = document.getElementById("toggle-up2");
const pasosTitle2 = document.getElementById("pasosTitle2");
const pasosP2 = document.getElementById("pasosP2");

toggleDown2.addEventListener("click", () => {
    pasosP2.classList.toggle("pasosP--show");
    pasosTitle2.classList.toggle("pasosTitle--hidden")
});

toggleUp2.addEventListener("click", () => {
    pasosP2.classList.toggle("pasosP--show");
    pasosTitle2.classList.toggle("pasosTitle--hidden")
});

const toggleDown3 = document.getElementById("toggle-down3");
const toggleUp3 = document.getElementById("toggle-up3");
const pasosTitle3 = document.getElementById("pasosTitle3");
const pasosP3 = document.getElementById("pasosP3");

toggleDown3.addEventListener("click", () => {
    pasosP3.classList.toggle("pasosP--show");
    pasosTitle3.classList.toggle("pasosTitle--hidden")
});

toggleUp3.addEventListener("click", () => {
    pasosP3.classList.toggle("pasosP--show");
    pasosTitle3.classList.toggle("pasosTitle--hidden")
});

const toggleDown4 = document.getElementById("toggle-down4");
const toggleUp4 = document.getElementById("toggle-up4");
const pasosTitle4 = document.getElementById("pasosTitle4");
const pasosP4 = document.getElementById("pasosP4");

toggleDown4.addEventListener("click", () => {
    pasosP4.classList.toggle("pasosP--show");
    pasosTitle4.classList.toggle("pasosTitle--hidden")
});

toggleUp4.addEventListener("click", () => {
    pasosP4.classList.toggle("pasosP--show");
    pasosTitle4.classList.toggle("pasosTitle--hidden")
});
